#Autori: Alexanda, Mihai, Andrei

# Algoritm MyHill Nerode

from collections import deque
import queue
import sys

file = sys.argv[0]
input_file = sys.argv[1]


def citireSiValidare():
   f = open(input_file,"r")
   lines = f.readlines()
   for i in range(len(lines)):
       lines[i]=lines[i].rstrip("\n")
   i=0;
   sigma=[]
   j=0
   dictionar = {}
   final=[]
   start=[]
   states=[]



   while (i < len(lines)):
      if (lines[i] == "Sigma:"):
         i+=1
         while (lines[i] != "End"):
            sigma.append(lines[i])
            i+=1
         i+=1
      if (lines[i] == "States:"):
         i+=1
         while (lines[i] != "End"):
            linie = lines[i].split(" ,")
            dictionar[linie[0]] = j
            if (len(linie) != 1):
               if (linie[1] == "S"):
                  start.append(linie[0])
               if (linie[1] == "F"):
                  final.append(linie[0])

            states.append(linie[0])
            j+=1
            i+=1
         i+=1

      matriceAdiacenta = [["#" for x in range(len(dictionar.keys()))] for y in range(len(dictionar.keys()))]

      if (lines[i] == "Transitions:"):
         i+=1
         while (lines[i] != "End"):
            linie = lines[i].split(" ,")
            if (len(linie) != 3):
               print("Invalid: element care nu apartine multimii starilor")
               return 0
            if (linie[0] not in dictionar.keys() or linie[2] not in dictionar.keys()):
               print("Invalid: element care nu apartine multimii starilor")
               return 0

            if (linie[1] not in sigma):
               print("Invalid: element care nu apartine alfabetului")
               return 0

            matriceAdiacenta[dictionar[linie[0]]][dictionar[linie[2]]] = linie[1];

            i+=1

         i+=1
      i+=1

   if (len(start) != 1):
      print("Invalid: mai multe stari sunt setate ca stari initiale")
      return 0

   if (len(final) < 1):
      print("Invalid: nu exista stari finale")
      return 0

   n = len(dictionar.keys())

   for el in matriceAdiacenta:
      for i in range(0, len(el)-1):
         for j in range(i+1, len(el)):
            if (el[i] == el[j] and el[i]!="#"):
               print("Invalida: pleaca doua muchii cu acelasi nume dintr-un singur nod")
               return 0

   finals=[]
   for el in final:
      finals.append(dictionar[el])
   return matriceAdiacenta, dictionar[start[0]], finals, len(dictionar), states, dictionar, sigma


def get_key(val):
   for key, value in dictionar.items():
      if val == value:
         return key


def get_key2(val):
   for key, value in nume_stari_finale.items():
      if val == value:
         return key

if __name__ == "__main__":
   DFA = citireSiValidare()


   matriceAdiacenta = DFA[0]
   start = DFA[1]
   finals = DFA[2]
   n = DFA[3]
   states = DFA[4]
   dictionar = DFA[5]
   sigma= DFA[6]

   tranzitii = []


   for i in range(n):
      for j in range(n):
         if(matriceAdiacenta[i][j] != '#'):
           tranzitii.append((get_key(i), get_key(j), matriceAdiacenta[i][j]))


   mat = [["#" for x in range(n)] for y in range(n)]

   for i in range(n):
      for j in range(i):
         if (i in finals and j not in finals) or (i not in finals and j in finals):
            mat[i][j] = 1
         else: mat[i][j] = 0

   lista_adiacenta= [["#" for x in range(len(sigma))] for y in range(n)]

   for q in states:
      for s in sigma:
         for q2 in states:
            if (q,q2,s) in tranzitii:
               lista_adiacenta[dictionar[q]][sigma.index(s)] = dictionar[q2]

   # Lista de adiacenta completa dupa urmatoarea forma: pe linia qK si sigmaT => elementul in care ajungem plecaand din qK prin muchia sigmaT




   while(True):
      modificat = False
      for i in range(n):
         for j in range(i):
            if mat[i][j] == 0:
               for s in sigma:
                  if lista_adiacenta[i][sigma.index(s)] != '#' and lista_adiacenta[j][sigma.index(s)] != '#':
                     if mat[lista_adiacenta[i][sigma.index(s)]][lista_adiacenta[j][sigma.index(s)]] == 1:
                        mat[i][j] = 1;
                        modificat=True
      if not modificat:
         break


   stari_noi = []

   for i in range(n):
      for j in range(i):
         if (mat[i][j] == 0):
            if (len(stari_noi)==0):
               stari_noi.append([i,j])

            else:
               for el in stari_noi:
                  if (i in el and j in el):
                     break
                  elif i in el and j not in el:
                     el.append(j)
                  elif j in el and i not in el:
                     el.append(i)
                  else:
                     stari_noi.append([i,j])


   stari_finale = stari_noi.copy()
   for el in states:
      for el2 in stari_noi:
         if dictionar[el] not in el2:
            stari_finale.append([dictionar[el]])
            break

   index=n
   nume_stari_finale={}
   for el in stari_finale:
      if (len(el) == 1):
         nume_stari_finale[str((get_key(el[0])))] = el
      else:
         nume_stari_finale["q"+str(index)] = el
         index+=1

   output = open("rezultat.txt", "w")
   output.write ("Sigma:\n")
   for el in sigma:
      output.write(el)
      output.write("\n")

   output.write ("End\n")
   output.write ("States:\n")

   for el in stari_finale:
      e_final = False
      e_start = False
      for i in el:
         if (i in finals):
            e_final = True
         elif (i == start):
            e_start = True
      if e_final and e_start:
         output.write(get_key2(el) + " ," + 'F' + ' ,S\n')
      elif e_final:
         output.write(get_key2(el) + " ," + 'F\n')
      elif e_start:
         output.write(get_key2(el) + " ," + 'S\n')
      else:
         output.write(get_key2(el))
         output.write("\n")

   output.write ("End\n")
   output.write("Transitions:\n")
   for el in stari_finale:
      for i in el:
         for el2 in stari_finale:
            for j in el2:
               if (matriceAdiacenta[i][j] != '#'):
                  output.write (get_key2(el) + " ," + get_key2(el2) + " ," + matriceAdiacenta[i][j])
                  output.write("\n")
   output.write ("End\n")


   #Fisierul rezultat este "rezultat.txt"
